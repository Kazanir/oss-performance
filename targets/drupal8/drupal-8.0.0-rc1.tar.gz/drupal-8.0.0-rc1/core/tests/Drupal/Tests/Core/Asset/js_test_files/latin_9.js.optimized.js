var latin9Char = '€';
